package com.demo.service;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.beans.Customer;
import com.demo.beans.DeliveryAgent;
import com.demo.beans.Dish;
import com.demo.beans.Oid;
import com.demo.beans.Order;
import com.demo.beans.OrderDish;
import com.demo.beans.OrderInfo;
import com.demo.beans.ShopInfo;
import com.demo.dao.OrderDao;
import com.demo.dao.OrderInfoDao;

@Service
public class OrderInfoService implements IorderInfo{

	@Autowired
	OrderInfoDao orderDao;





	@Override
	public List<OrderInfo> displayAllOrderHistoryByCustomerId(int i) {
		System.out.println("customer id" + i);
		//return orderDao.findAllById(i);
		return orderDao.getAllOrderHistoryByCustomerId(i);
	}





	@Override
	public List<OrderInfo> displayAllDeliveryAgentOrder(int daId) {
	
		return orderDao.findOrders(daId);
	}

}