package com.demo.beans;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="shop_info_table")
public class ShopInfo {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int shopId;
	
	private String shopName;
	
	private String shopType;
	
	private String shopAddress;
	
	private String shopOwnerName;
	
	private String phone;
	
	private String email;
	
	private String password;
	
	private String isActive;
	
	@Lob
	private String image;
	 
	@OneToMany(mappedBy="shop")
	private List<Order> order;
	
	@OneToMany(mappedBy="shop",cascade=CascadeType.ALL)
//	@JsonManagedReference
	private List<Dish> dish;
	
//	@Lob 
//	private byte[] imageReal;
//	
	public ShopInfo() {
		super();
	}
	

public ShopInfo(int shopId, String shopName, String shopType, String shopAddress, String shopOwnerName,
			String phone, String email, String password, String isActive, String image,List<Order> order
			//, byte[] imageReal
			) {
		super();
		this.shopId = shopId;
		this.shopName = shopName;
		this.shopType = shopType;
		this.shopAddress = shopAddress;
		this.shopOwnerName = shopOwnerName;
		this.phone = phone;
		this.email = email;
		this.password = password;
		this.isActive = isActive;
		this.image = image;
		this.order = order;
		//this.imageReal = imageReal;
	}


//	public ShopInfo(String shopName, String shopType, String shopAddress, String shopOwnerName, String phone,
//			String email, String password, String isActive, String image) {
//		super();
//		this.shopName = shopName;
//		this.shopType = shopType;
//		this.shopAddress = shopAddress;
//		this.shopOwnerName = shopOwnerName;
//		this.phone = phone;
//		this.email = email;
//		this.password = password;
//		this.isActive = isActive;
//		this.image = image;
//	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getShopType() {
		return shopType;
	}

	public void setShopType(String shopType) {
		this.shopType = shopType;
	}

	public String getShopAddress() {
		return shopAddress;
	}

	public void setShopAddress(String shopAddress) {
		this.shopAddress = shopAddress;
	}

	public String getShopOwnerName() {
		return shopOwnerName;
	}

	public void setShopOwnerName(String shopOwnerName) {
		this.shopOwnerName = shopOwnerName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}


	  public String getImage() { return image; }
	 
	 public void setImage(String image) { this.image = image; }
	 
    
	
//	public byte[] getImage1() {
//		return imageReal;
//	}
//
//	public void setImage1(byte[] imageReal) {
//		this.imageReal = imageReal;
//	}
//	
	
//	 public byte[] getImageReal() {
//			return imageReal;
//		}
//
//		public void setImageReal(byte[] imageReal) {
//			this.imageReal = imageReal;
//		}
//	 
	
	
//
//	public List<Order> getOrder() {
//		return order;
//	}
//
//
//	public void setOrder(List<Order> order) {
//		this.order = order;
//	}

	
	
	
	
	
	@Override
	public String toString() {
		return "ShopInfo [shopId=" + shopId + ", shopName=" + shopName + ", shopType=" + shopType + ", shopAddress="
				+ shopAddress + ", shopOwnerName=" + shopOwnerName + ", phone=" + phone + ", email=" + email
				+ ", isActive=" + isActive + "]";
	}
	
	
	
	
	
	
	
//	@Override
//	public String toString() {
//		return "ShopInfo [shopId=" + shopId + ", shopName=" + shopName + ", shopType=" + shopType + ", shopAddress="
//				+ shopAddress + ", shopOwnerName=" + shopOwnerName + ", phone=" + phone + ", email=" + email
//				+ ", password=" + password + ", isActive=" + isActive + ", image=" + image + "]";
//	}
	
}
