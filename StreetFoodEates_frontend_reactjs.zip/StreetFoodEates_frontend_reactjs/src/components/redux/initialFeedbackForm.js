export const initialFeedback = {
  firstName: '',
  lastName: '',
  contactNum: '',
  email: '',
  agree: false,
  contactType: 'Tel.',
  message: '',
}