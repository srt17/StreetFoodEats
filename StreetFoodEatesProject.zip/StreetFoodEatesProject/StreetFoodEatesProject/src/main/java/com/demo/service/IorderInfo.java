package com.demo.service;

import java.util.List;

import com.demo.beans.Order;
import com.demo.beans.OrderInfo;


public interface IorderInfo {

	List<OrderInfo> displayAllOrderHistoryByCustomerId(int i);

	List<OrderInfo> displayAllDeliveryAgentOrder(int daId);

	
}
