package com.demo.beans;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="order_Info")
public class OrderInfo {

//	order_1 = order_received_date_and_time, status , total_amount
//			dish = dish_name, dish_category
//			shop_info_table = shop_name, phone
//			delivery_agent = delivery_agent_name, delivery_agent_phone_no
//			customer = customer_address

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int orderInfoId;
	
	private String status;
	
    private String customerName;
		

	
	Date orderReceivedDateAndTime;
	double totalAmount;
	private String dishName;
	private String dishCategory;
	
	private int  deliveryAgentId;
	private int customerId;
	
	
	private String shopName;
	private String phone;
	private String deliveryAgentName;
	private String deliveryAgentPhoneNo;
	private String customerAddress;
	
	
	
	
	
	public OrderInfo() {
		super();
	}
	public OrderInfo(int orderInfoId, String status, String customerName, Date orderReceivedDateAndTime,
			double totalAmount, String dishName, String dishCategory, int deliveryAgentId, int customerId,
			String shopName, String phone, String deliveryAgentName, String deliveryAgentPhoneNo,
			String customerAddress) {
		super();
		this.orderInfoId = orderInfoId;
		this.status = status;
		this.customerName = customerName;
		this.orderReceivedDateAndTime = orderReceivedDateAndTime;
		this.totalAmount = totalAmount;
		this.dishName = dishName;
		this.dishCategory = dishCategory;
		this.deliveryAgentId = deliveryAgentId;
		this.customerId = customerId;
		this.shopName = shopName;
		this.phone = phone;
		this.deliveryAgentName = deliveryAgentName;
		this.deliveryAgentPhoneNo = deliveryAgentPhoneNo;
		this.customerAddress = customerAddress;
	}
	public int getOrderInfoId() {
		return orderInfoId;
	}
	public void setOrderInfoId(int orderInfoId) {
		this.orderInfoId = orderInfoId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Date getOrderReceivedDateAndTime() {
		return orderReceivedDateAndTime;
	}
	public void setOrderReceivedDateAndTime(Date orderReceivedDateAndTime) {
		this.orderReceivedDateAndTime = orderReceivedDateAndTime;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getDishName() {
		return dishName;
	}
	public void setDishName(String dishName) {
		this.dishName = dishName;
	}
	public String getDishCategory() {
		return dishCategory;
	}
	public void setDishCategory(String dishCategory) {
		this.dishCategory = dishCategory;
	}
	public int getDeliveryAgentId() {
		return deliveryAgentId;
	}
	public void setDeliveryAgentId(int deliveryAgentId) {
		this.deliveryAgentId = deliveryAgentId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getDeliveryAgentName() {
		return deliveryAgentName;
	}
	public void setDeliveryAgentName(String deliveryAgentName) {
		this.deliveryAgentName = deliveryAgentName;
	}
	public String getDeliveryAgentPhoneNo() {
		return deliveryAgentPhoneNo;
	}
	public void setDeliveryAgentPhoneNo(String deliveryAgentPhoneNo) {
		this.deliveryAgentPhoneNo = deliveryAgentPhoneNo;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	@Override
	public String toString() {
		return "OrderInfo [orderInfoId=" + orderInfoId + ", status=" + status + ", customerName=" + customerName
				+ ", orderReceivedDateAndTime=" + orderReceivedDateAndTime + ", totalAmount=" + totalAmount
				+ ", dishName=" + dishName + ", dishCategory=" + dishCategory + ", deliveryAgentId=" + deliveryAgentId
				+ ", customerId=" + customerId + ", shopName=" + shopName + ", phone=" + phone + ", deliveryAgentName="
				+ deliveryAgentName + ", deliveryAgentPhoneNo=" + deliveryAgentPhoneNo + ", customerAddress="
				+ customerAddress + "]";
	}
	
	

}



//package com.demo.beans;
//
//import java.util.Date;
//
//import javax.persistence.Table;
//@Table(name="order_info")
//public class OrderInfo {
//
//	private int shopId;
//	private int dishId;
//	private String dishName;
//	private double price;	
//	private String description;
//	private String dishImage;
//	private int deliveryAgentId;
//	int orderId;
//	String status;
//	Date orderReceivedDateAndTime;
//	Date dispatchDateAndTime;
//	Date deliveryDateAndTime;
//	double totalAmount;
//	private int customerId;
//	int quantity;
//	double priceXquantity;
//	private String deliveryAgentName;
//	private String deliveryAgentPhoneNo;
//	private String shopName;
//	private String phone;
//	private boolean isActive;
//	
//	public OrderInfo() {
//		super();
//	}
//
//	public OrderInfo(int shopId, int dishId, String dishName, double price, String description, String dishImage,
//			int deliveryAgentId, int orderId, String status, Date orderReceivedDateAndTime, Date dispatchDateAndTime,
//			Date deliveryDateAndTime, double totalAmount, int customerId, int quantity, double priceXquantity,
//			String deliveryAgentName, String deliveryAgentPhoneNo, String shopName, String phone, boolean isActive) {
//		super();
//		this.shopId = shopId;
//		this.dishId = dishId;
//		this.dishName = dishName;
//		this.price = price;
//		this.description = description;
//		this.dishImage = dishImage;
//		this.deliveryAgentId = deliveryAgentId;
//		this.orderId = orderId;
//		this.status = status;
//		this.orderReceivedDateAndTime = orderReceivedDateAndTime;
//		this.dispatchDateAndTime = dispatchDateAndTime;
//		this.deliveryDateAndTime = deliveryDateAndTime;
//		this.totalAmount = totalAmount;
//		this.customerId = customerId;
//		this.quantity = quantity;
//		this.priceXquantity = priceXquantity;
//		this.deliveryAgentName = deliveryAgentName;
//		this.deliveryAgentPhoneNo = deliveryAgentPhoneNo;
//		this.shopName = shopName;
//		this.phone = phone;
//		this.isActive = isActive;
//	}
//
//	public int getShopId() {
//		return shopId;
//	}
//
//	public void setShopId(int shopId) {
//		this.shopId = shopId;
//	}
//
//	public int getDishId() {
//		return dishId;
//	}
//
//	public void setDishId(int dishId) {
//		this.dishId = dishId;
//	}
//
//	public String getDishName() {
//		return dishName;
//	}
//
//	public void setDishName(String dishName) {
//		this.dishName = dishName;
//	}
//
//	public double getPrice() {
//		return price;
//	}
//
//	public void setPrice(double price) {
//		this.price = price;
//	}
//
//	public String getDescription() {
//		return description;
//	}
//
//	public void setDescription(String description) {
//		this.description = description;
//	}
//
//	public String getDishImage() {
//		return dishImage;
//	}
//
//	public void setDishImage(String dishImage) {
//		this.dishImage = dishImage;
//	}
//
//	public int getDeliveryAgentId() {
//		return deliveryAgentId;
//	}
//
//	public void setDeliveryAgentId(int deliveryAgentId) {
//		this.deliveryAgentId = deliveryAgentId;
//	}
//
//	public int getOrderId() {
//		return orderId;
//	}
//
//	public void setOrderId(int orderId) {
//		this.orderId = orderId;
//	}
//
//	public String getStatus() {
//		return status;
//	}
//
//	public void setStatus(String status) {
//		this.status = status;
//	}
//
//	public Date getOrderReceivedDateAndTime() {
//		return orderReceivedDateAndTime;
//	}
//
//	public void setOrderReceivedDateAndTime(Date orderReceivedDateAndTime) {
//		this.orderReceivedDateAndTime = orderReceivedDateAndTime;
//	}
//
//	public Date getDispatchDateAndTime() {
//		return dispatchDateAndTime;
//	}
//
//	public void setDispatchDateAndTime(Date dispatchDateAndTime) {
//		this.dispatchDateAndTime = dispatchDateAndTime;
//	}
//
//	public Date getDeliveryDateAndTime() {
//		return deliveryDateAndTime;
//	}
//
//	public void setDeliveryDateAndTime(Date deliveryDateAndTime) {
//		this.deliveryDateAndTime = deliveryDateAndTime;
//	}
//
//	public double getTotalAmount() {
//		return totalAmount;
//	}
//
//	public void setTotalAmount(double totalAmount) {
//		this.totalAmount = totalAmount;
//	}
//
//	public int getCustomerId() {
//		return customerId;
//	}
//
//	public void setCustomerId(int customerId) {
//		this.customerId = customerId;
//	}
//
//	public int getQuantity() {
//		return quantity;
//	}
//
//	public void setQuantity(int quantity) {
//		this.quantity = quantity;
//	}
//
//	public double getPriceXquantity() {
//		return priceXquantity;
//	}
//
//	public void setPriceXquantity(double priceXquantity) {
//		this.priceXquantity = priceXquantity;
//	}
//
//	public String getDeliveryAgentName() {
//		return deliveryAgentName;
//	}
//
//	public void setDeliveryAgentName(String deliveryAgentName) {
//		this.deliveryAgentName = deliveryAgentName;
//	}
//
//	public String getDeliveryAgentPhoneNo() {
//		return deliveryAgentPhoneNo;
//	}
//
//	public void setDeliveryAgentPhoneNo(String deliveryAgentPhoneNo) {
//		this.deliveryAgentPhoneNo = deliveryAgentPhoneNo;
//	}
//
//	public String getShopName() {
//		return shopName;
//	}
//
//	public void setShopName(String shopName) {
//		this.shopName = shopName;
//	}
//
//	public String getPhone() {
//		return phone;
//	}
//
//	public void setPhone(String phone) {
//		this.phone = phone;
//	}
//
//	public boolean isActive() {
//		return isActive;
//	}
//
//	public void setActive(boolean isActive) {
//		this.isActive = isActive;
//	}
//
//	@Override
//	public String toString() {
//		return "OrderInfo [shopId=" + shopId + ", dishId=" + dishId + ", dishName=" + dishName + ", price=" + price
//				+ ", description=" + description + ", dishImage=" + dishImage + ", deliveryAgentId=" + deliveryAgentId
//				+ ", orderId=" + orderId + ", status=" + status + ", orderReceivedDateAndTime="
//				+ orderReceivedDateAndTime + ", dispatchDateAndTime=" + dispatchDateAndTime + ", deliveryDateAndTime="
//				+ deliveryDateAndTime + ", totalAmount=" + totalAmount + ", customerId=" + customerId + ", quantity="
//				+ quantity + ", priceXquantity=" + priceXquantity + ", deliveryAgentName=" + deliveryAgentName
//				+ ", deliveryAgentPhoneNo=" + deliveryAgentPhoneNo + ", shopName=" + shopName + ", phone=" + phone
//				+ ", isActive=" + isActive + "]";
//	}
//
//	
//}

